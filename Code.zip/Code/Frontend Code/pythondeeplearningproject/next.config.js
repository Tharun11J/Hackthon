/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  env: {
    BASE_URL: "https://python-deeplearning.herokuapp.com/",
    MONGO_URI: "mongodb+srv://saicharan:saicharan@cluster0.tjiy8.mongodb.net/PythonDeepLearning?retryWrites=true&w=majority"
  }
}

module.exports = nextConfig
