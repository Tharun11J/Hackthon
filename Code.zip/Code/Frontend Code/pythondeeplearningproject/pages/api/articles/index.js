import dbConnect from "../../../db/dbConnect";
import Article from "../../../models/Article";

dbConnect();

export default async (req, res) => {
  const { method } = req;

  switch (method) {
    case "GET":
      try {
        const articles = await Article.find({});
        res.status(200).json({ success: true, articles });
      } catch (error) {
        res.status(500).json({ success: false });
      }
      break;
    default:
      res.status(400).json({ success: false });
      break;
  }
};
