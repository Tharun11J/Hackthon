import { useEffect, useState } from "react";
import axios from "axios";
import dbConnect from "../db/dbConnect";
import Navbar from "../components/Navbar";
import styles from "./index.module.css";
import Card from "../components/Card";
import Head from "next/head";

dbConnect();

function Home({ articles }) {
  const [selectedNavItem, setSelectedNavItem] = useState("");
  const [navbarItems, setNavbarItems] = useState();
  const [articlesList, setArticlesList] = useState(articles);
  useEffect(() => {
    const uniqueTags = [...new Set(articles.map((obj) => obj.tag))];
    let navItems = [];
    uniqueTags &&
      uniqueTags.map((tag, index) => {
        if (index === 0) {
          setSelectedNavItem(tag.charAt(0).toUpperCase() + tag.slice(1));
        }
        let item = {
          id: index + 1,
          name: tag.charAt(0).toUpperCase() + tag.slice(1),
        };
        navItems.push(item);
      });
    setNavbarItems(navItems);
    let firstTag = uniqueTags[0].tag;
    setArticlesList(articles.filter((article) => article.tag === firstTag));
  }, []);

  useEffect(() => {
    if (selectedNavItem !== "") {
      let name = selectedNavItem.charAt(0).toLowerCase() + selectedNavItem.slice(1);
      setArticlesList(articles.filter((article) => article.tag === name));
    }
  }, [selectedNavItem]);


  return (
    <div>
      <Head>
        <title>Articles Classifier</title>
      </Head>
      <Navbar
        selectedNavItem={selectedNavItem}
        setSelectedNavItem={setSelectedNavItem}
        navbarItems={navbarItems}
      />
      <div className={`${styles.container} container`}>
        <div className="row">
          {articlesList.map((article, i) => (
            <div key={i} className={`col-4 ${styles.cardStyle}`}>
              <Card key={i} article={article} index={i}/>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export async function getServerSideProps(context) {
  const res = await axios("http://localhost:3000/api/articles");
  const { articles } = res.data;
  return {
    props: { articles },
  };
}

export default Home;
