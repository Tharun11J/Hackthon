const mongoose = require("mongoose");

const ArticleSchema = new mongoose.Schema({
  title: {
    type: String,
  },
  image: {
    type: String,
  },
  content: {
    type: String,
  },
  link: {
    type: String
  },
  tags: {
    type: String
  }
});

module.exports = mongoose.models.Article || mongoose.model('Article', ArticleSchema)