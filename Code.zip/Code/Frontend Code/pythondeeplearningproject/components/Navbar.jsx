import {
  MDBContainer,
  MDBNavbar,
  MDBNavbarBrand,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBCollapse,
} from "mdb-react-ui-kit";
import Image from 'next/image'
import classifierlogo from '../images/classifierlogo.png';

export default function Navbar(props) {
  const { selectedNavItem, setSelectedNavItem, navbarItems } = props;
  return (
    <MDBNavbar expand="lg" light bgColor="light">
      <MDBContainer fluid>
        <MDBNavbarBrand href="/">
          <Image
            src={classifierlogo}
            height="50"
            width="50"
            alt=""
            loading="lazy"
          />
        </MDBNavbarBrand>
        <MDBCollapse navbar>
          <MDBNavbarNav>
              {navbarItems && navbarItems.map((item) => (
                <MDBNavbarItem key={item.id} onClick={() => setSelectedNavItem(item.name)}>
                    <MDBNavbarLink active={item.name === selectedNavItem}>{item.name}</MDBNavbarLink>
                </MDBNavbarItem>
              ))}
          </MDBNavbarNav>
        </MDBCollapse>
      </MDBContainer>
    </MDBNavbar>
  );
}
