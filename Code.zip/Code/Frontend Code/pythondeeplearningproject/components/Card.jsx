import React, { useEffect } from "react";
import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText
} from "mdb-react-ui-kit";

export default function Card(props) {
  const { article, index } = props;

  const setBackgroundColor = () => {
    document.getElementById(
      `bg-image-${article.title}-${index}`
    ).style.backgroundColor = `#${Math.floor(Math.random() * 16777215).toString(
      16
    )}`;
  };

  useEffect(() => {
    setBackgroundColor();
  }, []);

  return (
    <a
      target="_blank"
      href={article.link}
      rel="noopener noreferrer"
      style={{ color: "inherit" }}
    >
      <MDBCard style={{ maxWidth: "22rem" }}>
       
        <div
          id={`bg-image-${article.title}-${index}`}
          style={{
            height: 200,
            fontSize: 100,
            color: "#ffffff",
            justifyContent: "center",
            alignItems: "center",
            textAlign: "center",
          }}
        >
          <p style={{ marginTop: 25 }}>
            {article.title.charAt(0).toUpperCase()}
          </p>
        </div>
        <MDBCardBody>
          <MDBCardTitle style={{ height: 48 }}>
            {article.title.length > 60
              ? `${article.title.substring(0, 60)} ...`
              : article.title}
          </MDBCardTitle>
          <MDBCardText style={{ height: 77 }}>
            {article.content.length > 114
              ? `${article.content.substring(0, 114)} ...`
              : article.content}
          </MDBCardText>
        </MDBCardBody>
      </MDBCard>
   </a>
  );
}
